import os
import shutil
import subprocess
import sys
import time

# 需要部署的文件夹路径
source_path = "./"
# 程序部署的路径
app_path = "/data/app/D.ACT/"

# django配置文件，如：settings_uat.py，未找到到执行settings.py
settings_root_path = "/data/app/D.ACT/tara/"
settings_name = "settings"
# 需要替换的文件夹
dirs = [
    "tara", "statics", "templates"
]
wait_time = 3


def main():
    start_time = time.time()
    print(f"[timer] 开始处理时间：{start_time}")

    env = ""
    if len(sys.argv) > 2 and sys.argv[1] == "-e":
        env = sys.argv[2]

    # 检查参数是否正确
    print("[info ] 检查配置参数是否正确")
    err = check_params()
    if not err and err != "":
        print(f"[error]{err}")
        return

    # 关闭uwsgi
    print("[info ]停止uwsgi服务...")
    stop_uwsgi = execute_system("uwsgi --stop " + app_path + "uwsgi.pd")
    time.sleep(1)
    if not stop_uwsgi:
        print("[warn ]关闭uwsgi失败")

    # 删除源文件 并且移动
    for tdir in dirs:
        source_dir_path = source_path + tdir
        app_dir_path = app_path + tdir
        if os.path.exists(app_dir_path):
            print("[info ]删除原始项目下的文件夹:%s" % app_dir_path)
            shutil.rmtree(app_dir_path)
        print("[info ] 移动文件夹(%s->%s)" % (source_dir_path, app_dir_path))
        shutil.move(source_dir_path, app_dir_path)
    # 替换settings文件
    print(f"[info ]Env is {env} ")
    if env:
        print("[info ]替换配置文件以指定环境启动")
        settings_env_file_path = settings_root_path + settings_name + "_" + env + ".py"
        if os.path.exists(settings_env_file_path):
            settings_file_path = settings_root_path + settings_name + ".py"
            # 删除默认配置文件
            if os.path.exists(settings_file_path):
                print(f"[info ]删除文件:{settings_file_path}")
                os.remove(settings_file_path)
            print(f"[info ]重命名文件:{settings_env_file_path}")
            os.rename(settings_env_file_path, settings_file_path)
        else:
            print(f"[warn ]未找到配置文件{settings_env_file_path}")

    # 启动uwsgi
    print("[info ]启动uwsgi服务...")
    start_uwsgi = execute_system("uwsgi -d --ini " + app_path + "uwsgi.ini")
    time.sleep(1)
    if not start_uwsgi:
        print("[error ]启动uwsgi失败")
        return
    print("[info ] 执行完成")

    end_time = time.time()
    print(f"[timer] 处理完成时间：{end_time}")
    count_time = end_time - start_time
    print(f"[timer] 一共耗时：：{round(count_time, 3)}秒")


# 重启uwsgi
# uwsgi --reload /data/app/D.ACT/uwsgi.pid


def check_params() -> str:
    if len(dirs) < 1:
        return "[error]需要移动的文件夹不存在"
    for source_dir in dirs:
        if not os.path.exists(source_path + source_dir):
            return "[error](%s)文件夹不存在" % source_dir
    return ""


def execute_system(cmd: str) -> bool:
    return os.system(cmd) == 0


def execute_cmd(cmd, code="utf8"):
    print(cmd)
    process = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    while process.poll() is None:
        line = process.stdout.readline()
        line = line.strip()
        if line:
            print(line.decode(code, 'ignore'))


if __name__ == '__main__':
    main()
