
# 一、开发环境搭建
## 1.安装python
python 版本 >=3.6

## 2.安装python虚拟环境env
在安装python 在控制台中执行以下命令
```commandline
pip install virtualenv
```
## 3.创建虚拟环境
### 3.1. 进入项目的根目录    
> 例：我的项目目录[c:\projects\D.ACT] (需替换成你的)

### 3.2. 在目录下执行以下命令 
 
```commandline
python -m  venv tara_env
```
### 3.3.进入刚才创建的虚拟环境tara_env的Scripts文件夹下，执行以下命令
```commandline
activate
```
> 例：我现在的路径为：c:\projects\D.ACT\tara_evv\Scripts
> 
注：windows 下如果报错可替换为[ .\activate ]
激活后控制台的目录前将会显示一个（tara_env）,输入pip list 应该只有2-3个库
> 例：(tara_env) PS C:\Projects\D.ACT\tara_env\Scripts> 

退出虚拟环境的命令为：deactivate，一般不用退出

## 4.安装项目所需依赖库
### 4.1 激活虚拟环境后在虚拟环境所属的控制台下执行命令 [requirement.txt]需要指定路径，如果在document下执行就不用
```commandline
pip install -r requirement.txt
```

> 例：我现在控制台的路径为(tara_env) PS C:\Projects\D.ACT\tara_env\Scripts> ,那么我要执行这个命令就需要指定requirement.txt的路径

> 如：pip install -r C:\Projects\D.ACT\document.txt

执行过后根据网速的不同会耗一些时间安装所需依赖库

## 5.开发Idea选择
### 5.1 PyCharm
推荐使用PyCharm社区最新版，无特殊版本要求

####  5.1.1 PyCharm 导入项目
> 左上角点击File打开文件夹，选择项目路径即可

#### 5.1.2 PyCharm虚拟环境选择
> File > Settings > Project: D.ACT > Python Interpreter > Add Local Interpreter

选择刚才创建的虚拟环境根目录即可

### 5.2 VsCode
推荐使用最新版本，无特殊版本要求

## 6.数据库
### 6.1 安装数据库
#### 6.1.2 安装MariaDb最新版即可
#### 6.1.3 创建数据库
CREATE DATABASE project_space;
CREATE DATABASE tara;


### 6.2 导入数据库初始化内容
使用工具或者命令行导入document/sql文件
### 6.2.1 在tara库中执行导入tara_ddl.sql
### 6.2.2 在tara库中执行导入tara_dml.sql
### 6.2.3 在tara库中执行导入project_status.sql

> 注意导入顺序

## 7.生成自签证书
### 7.1 由于项目需要https启动，所以需要一个证书，生成环境需联系its获取正式证书并且替换到项目目录下

生成详情参考：[https://blog.csdn.net/ling1998/article/details/122019612](https://blog.csdn.net/ling1998/article/details/122019612)

### 7.2 生成完成后将server.crt、server.key两个文件移动到项目目录中
> 例：C:\Projects\D.ACT\server.crt 、C:\Projects\D.ACT\server.key

### 8.更改settings文件
找到项目中的tara文件夹下的settings文件 ，将DATABASES中的数据库信息更改为你的数据库信息

## 9.启动项目
在python依赖库和证书生成并移动完成后，有两种方法本地启动项目
### 9.1 PyCharm启动
> 9.1.1 点击PyCharm 右上方启动按钮左侧的Run/Debug Configuration选项选择edit configuration

> 9.1.2 找到Script path 选择项目根目录下的manage.py文件，并在Paramenters中填入runserver_plus --cert server.crt 127.0.0.1:8000

### 9.2 控制台启动
直接在项目根路径下执行以下命令

* http
```commandline
python manage.py runserver 127.0.0.1:8080
```

* https
```commandline
python manage.py runserver_plus --cert server.crt 127.0.0.1:8000
```



一切顺利的话控制台将打印启动后的访问地址
# 二、测试/生产环境搭建

## 1. 安装 Ubuntu Server version: 20.04.3 LTS 让服务商安装好即可
## 2. 安装数据库MariaDB version: latest [安装教程](https://blog.csdn.net/a_small_cherry/article/details/122953002)

* 2.1 预创建project_space库以及tara库
* 2.2 在project_space库下执行document/SQL/project_status.sql文件
* 2.3 在tara库下执行document/sql/tara_ddl.sql ,document/sql/tara_dml.sql
 
 
## 3. 安装Nginx version: nginx/1.18.0 (Ubuntu) [安装教程](https://blog.csdn.net/baidu_41560343/article/details/107869458)

* 3.1 配置Nginx
* 3.2 将服务器说明.md文件中二、1.2中的配置内容复制到nginx的配置文件中
* 3.2 启动Nginx

这时候访问访问127.0.0.1:{port} 可以看到nginx的信息即启动成功


## 4. 安装uwsgi [安装教程](https://blog.csdn.net/yoke__/article/details/126152556)

* 3.2 参考服务器说明文件中的uwsgi启动即可，配置文件在根目录下，不需要单独配置

一切正常的话这个时候刷新127.0.0.1:{port} 即可看到项目信息