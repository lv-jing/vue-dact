/*
 Navicat Premium Data Transfer

 Source Server         : mysql-tara
 Source Server Type    : MySQL
 Source Server Version : 50739
 Source Host           : 192.168.203.133:3306
 Source Schema         : tara

 Target Server Type    : MySQL
 Target Server Version : 50739
 File Encoding         : 65001

 Date: 05/12/2022 15:19:00
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for attack_tree
-- ----------------------------
DROP TABLE IF EXISTS `attack_tree`;
CREATE TABLE `attack_tree`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_id` int(11) NULL DEFAULT NULL COMMENT '对象ID（对应表projects）（0表示系统预设的树）',
  `node_id` bigint(20) NULL DEFAULT NULL COMMENT '节点ID（对应表dictionary_invoke的字段id）',
  `level` tinyint(4) NULL DEFAULT NULL COMMENT '层级',
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `desc` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '描述',
  `attack_description` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '攻击描述',
  `sort_id` int(11) UNSIGNED NOT NULL COMMENT '排序号（默认值同id）',
  `parent_id` int(11) NOT NULL DEFAULT 0 COMMENT '父ID（0代表顶层）',
  `creator_id` int(11) NOT NULL COMMENT '建立人用户ID（对应表auth_user）',
  `created_at` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `attack_category_id` bigint(20) NULL DEFAULT NULL COMMENT '攻击树类型id',
  `damage_id` int(11) NULL DEFAULT NULL COMMENT '资产属性id',
  `active` tinyint(1) UNSIGNED NULL DEFAULT 0 COMMENT '前置资产是否存在',
  `space_id` int(11) NULL DEFAULT NULL COMMENT '项目空间id',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `target_id`(`target_id`) USING BTREE,
  INDEX `node_id`(`node_id`) USING BTREE,
  INDEX `sort_id`(`sort_id`) USING BTREE,
  INDEX `parent_id`(`parent_id`) USING BTREE,
  INDEX `creator_id`(`creator_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12669 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '攻击树' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for attack_tree_options
-- ----------------------------
DROP TABLE IF EXISTS `attack_tree_options`;
CREATE TABLE `attack_tree_options`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `attack_tree_id` bigint(20) NOT NULL COMMENT '节点id',
  `threat_reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `requirement_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `concept_brief` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `mitigation_ref_regulation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `creator_id` int(11) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_by` int(11) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `space_id` int(11) NULL DEFAULT NULL COMMENT '项目空间id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7945 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for attack_tree_relation
-- ----------------------------
DROP TABLE IF EXISTS `attack_tree_relation`;
CREATE TABLE `attack_tree_relation`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `attack_tree_id` bigint(20) NOT NULL COMMENT '节点id',
  `parent_id` bigint(20) NOT NULL COMMENT '父节点',
  `creator_id` int(11) NOT NULL COMMENT '创建人',
  `created_at` datetime(0) NOT NULL COMMENT '创建时间',
  `updated_by` int(11) NULL DEFAULT NULL COMMENT '更新人',
  `updated_at` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime(0) NULL DEFAULT NULL COMMENT '删除标识',
  `project_id` int(1) NOT NULL COMMENT '项目id',
  `space_id` int(11) NULL DEFAULT NULL COMMENT '项目空间id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10255 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '攻击树节点关系表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for attack_tree_vector
-- ----------------------------
DROP TABLE IF EXISTS `attack_tree_vector`;
CREATE TABLE `attack_tree_vector`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_id` int(11) NOT NULL COMMENT '项目id',
  `attack_tree_id` bigint(20) NOT NULL COMMENT '攻击树的节点id',
  `dict_id` bigint(20) NULL DEFAULT NULL COMMENT '引用的字典id',
  `dict_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '字典名称',
  `dict_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '字典描述',
  `creator_id` int(11) NOT NULL COMMENT '创建人',
  `created_at` datetime(0) NOT NULL COMMENT '创建时间',
  `updated_by` int(11) NULL DEFAULT NULL COMMENT '更新人',
  `updated_at` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime(0) NULL DEFAULT NULL COMMENT '删除标识',
  `category_id` bigint(20) NULL DEFAULT NULL COMMENT '分类id',
  `page_type` int(11) NOT NULL DEFAULT 1 COMMENT '页面类型 1 节点页面 2分值页面',
  `dict_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典值',
  `space_id` int(11) NULL DEFAULT NULL COMMENT '项目空间id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 101822 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '攻击树节点数据' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_group_permissions_group_id_permission_id_0cd325b0_uniq`(`group_id`, `permission_id`) USING BTREE,
  INDEX `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm`(`permission_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `codename` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '代号',
  `desc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '描述',
  `sort_id` int(11) NOT NULL DEFAULT 0 COMMENT '排序ID',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `code`(`codename`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户权限' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `last_login` datetime(6) NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `last_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(254) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `login_failed` int(11) NOT NULL DEFAULT 0 COMMENT '登录失败次数',
  `display_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '完整的显示名称',
  `is_aad` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Azure AD 用户',
  `aad_display_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Azure AD 用户属性',
  `aad_job_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Azure AD 用户属性',
  `aad_office_location` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Azure AD 用户属性',
  `aad_given_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Azure AD 用户属性',
  `aad_surname` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Azure AD 用户属性',
  `aad_department` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Azure AD 用户属性',
  `aad_company_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Azure AD 用户属性',
  `aad_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Azure AD 用户属性',
  `aad_photo` mediumblob NULL COMMENT 'Azure AD 用户属性',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_groups_user_id_group_id_94350c0c_uniq`(`user_id`, `group_id`) USING BTREE,
  INDEX `auth_user_groups_group_id_97559544_fk_auth_group_id`(`group_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq`(`user_id`, `permission_id`) USING BTREE,
  INDEX `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm`(`permission_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 43 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'key',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `key_unique`(`key`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for dictionaries
-- ----------------------------
DROP TABLE IF EXISTS `dictionaries`;
CREATE TABLE `dictionaries`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) UNSIGNED NOT NULL COMMENT '分布式id',
  `type` tinyint(4) NOT NULL COMMENT '类别编号 1)asset category 2)asset 3)sub system 4)component 5)asset property 6)impact rating 7)impact level 8)attack tree 9)attack category 10)R155 threat reference 11)feasibility rating 12)feasibility level 14)risk value 15)requirement',
  `name` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `abbr` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '缩写',
  `sn` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '序列号/编号',
  `desc` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '描述',
  `value` decimal(10, 2) NULL DEFAULT NULL COMMENT '分值',
  `range_start` decimal(10, 2) NULL DEFAULT NULL COMMENT '分数范围（>=）',
  `range_end` decimal(10, 2) NULL DEFAULT NULL COMMENT '分数范围（<=）',
  `sort_id` int(11) NOT NULL DEFAULT 0 COMMENT '排序号（默认值同id）',
  `parent_id` bigint(20) NOT NULL DEFAULT 0 COMMENT '父ID（0代表顶层）（对应本表）',
  `front_ids` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '前置依赖，依赖（关联）哪些前置ID',
  `rear_ids` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '向后决策，决定（关联）后续哪些ID',
  `color` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '颜色',
  `creator_id` int(11) NOT NULL COMMENT '建立人用户ID（对应表auth_user）',
  `is_from_user` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 系统预设，1 管理员，2 用户',
  `created_at` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `system_default` tinyint(1) NULL DEFAULT NULL,
  `project_id` int(11) NULL DEFAULT NULL COMMENT '项目id',
  `space_id` int(11) NULL DEFAULT NULL COMMENT '项目空间id',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `type`(`type`) USING BTREE,
  INDEX `parent_id`(`parent_id`) USING BTREE,
  INDEX `creator_id`(`creator_id`) USING BTREE,
  INDEX `sort_id`(`sort_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10669 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '字典表，含各种分类、item' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for dictionaries_item
-- ----------------------------
DROP TABLE IF EXISTS `dictionaries_item`;
CREATE TABLE `dictionaries_item`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `category_id` bigint(20) NOT NULL COMMENT '所属分类',
  `parent_id` bigint(20) NOT NULL COMMENT '父编码',
  `dict_id` bigint(20) NOT NULL COMMENT '对应的sn',
  `creator_id` int(11) NOT NULL COMMENT '建立人用户ID（对应表auth_user）',
  `created_at` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `updated_id` int(11) NULL DEFAULT NULL,
  `space_id` int(11) NOT NULL COMMENT '项目空间id',
  `project_id` int(11) NOT NULL COMMENT '项目id',
  `attribute` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '额外属性字段',
  `category_parent_id` bigint(20) NULL DEFAULT NULL COMMENT '分类的父id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 661 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `object_repr` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content_type_id` int(11) NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `django_admin_log_content_type_id_c4bce8eb_fk_django_co`(`content_type_id`) USING BTREE,
  INDEX `django_admin_log_user_id_c564eba6_fk_auth_user_id`(`user_id`) USING BTREE,
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `_auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `model` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_content_type_app_label_model_76bd3d3b_uniq`(`app_label`, `model`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session`  (
  `session_key` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `session_data` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`) USING BTREE,
  INDEX `django_session_expire_date_a5c62663`(`expire_date`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for file_accessories
-- ----------------------------
DROP TABLE IF EXISTS `file_accessories`;
CREATE TABLE `file_accessories`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'UUID，同时也是存储后的文件名(*.*)',
  `store_path` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '存储路径（不含文件名）',
  `filename` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '原始文件名(*.*)',
  `desc` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '描述',
  `file_size` bigint(20) NULL DEFAULT NULL COMMENT '文件尺寸(Bytes)',
  `file_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '文件类型(pdf/ppt/word/excel)',
  `target_type` tinyint(4) NOT NULL COMMENT '关联对象 1)project 2)dictionariy',
  `target_id` int(11) NOT NULL COMMENT '对象ID',
  `target_object` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '引用对象 例 system_information, network_topology',
  `creator_id` int(11) NULL DEFAULT NULL COMMENT '建立人用户ID（对应表auth_user）',
  `created_at` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `updated_id` int(11) NULL DEFAULT NULL,
  `suffix` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '文件后缀',
  `space_id` int(11) NULL DEFAULT NULL COMMENT '项目空间id',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uuid`(`uuid`) USING BTREE,
  INDEX `target_id`(`target_id`) USING BTREE,
  INDEX `creator_id`(`creator_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 544 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '文件附件' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for libraries
-- ----------------------------
DROP TABLE IF EXISTS `libraries`;
CREATE TABLE `libraries`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '分布式id',
  `type` tinyint(4) NOT NULL COMMENT '类别编号 1)asset category 2)asset 3)sub system 4)component 5)asset property 6)impact rating 7)impact level 8)attack tree 9)attack category 10)R155 threat reference 11)feasibility rating 12)feasibility level 14)risk value 15)requirement',
  `name` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `abbr` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '缩写',
  `sn` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '序列号/编号',
  `desc` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '描述',
  `value` decimal(10, 2) NULL DEFAULT NULL COMMENT '分值',
  `range_start` decimal(10, 2) NULL DEFAULT NULL COMMENT '分数范围（>=）',
  `range_end` decimal(10, 2) NULL DEFAULT NULL COMMENT '分数范围（<=）',
  `sort_id` int(11) NOT NULL DEFAULT 0 COMMENT '排序号（默认值同id）',
  `parent_id` bigint(20) NOT NULL DEFAULT 0 COMMENT '父ID（0代表顶层）（对应本表）',
  `front_ids` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '前置依赖，依赖（关联）哪些前置ID',
  `rear_ids` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '向后决策，决定（关联）后续哪些ID',
  `color` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '颜色',
  `creator_id` int(11) NOT NULL COMMENT '建立人用户ID（对应表auth_user）',
  `is_from_user` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0管理员，1 用户',
  `created_at` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `system_default` tinyint(1) NULL DEFAULT 1 COMMENT '1',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `type`(`type`) USING BTREE,
  INDEX `parent_id`(`parent_id`) USING BTREE,
  INDEX `creator_id`(`creator_id`) USING BTREE,
  INDEX `sort_id`(`sort_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 285 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '字典表，含各种分类、item' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for libraries_item
-- ----------------------------
DROP TABLE IF EXISTS `libraries_item`;
CREATE TABLE `libraries_item`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `category_id` bigint(20) NOT NULL COMMENT '所属分类',
  `parent_id` bigint(20) NOT NULL COMMENT '父编码',
  `dict_id` bigint(20) NOT NULL COMMENT '对应的sn',
  `creator_id` int(11) NOT NULL COMMENT '建立人用户ID（对应表auth_user）',
  `created_at` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `updated_id` int(11) NULL DEFAULT NULL,
  `space_id` int(11) NOT NULL COMMENT '项目空间id',
  `project_id` int(11) NOT NULL COMMENT '项目id',
  `attribute` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '额外属性字段',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_assets
-- ----------------------------
DROP TABLE IF EXISTS `project_assets`;
CREATE TABLE `project_assets`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_id` int(11) NOT NULL COMMENT '项目id',
  `category_dict_id` decimal(20, 0) NOT NULL COMMENT '界面分类所属字典id',
  `category_dict_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典名称',
  `asset_dict_id` bigint(20) NOT NULL COMMENT '资产库id',
  `serial_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '资产库sn',
  `asset_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '资产名称',
  `asset_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '资产描述',
  `asset_property` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '资产属性',
  `component` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '组件',
  `comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '说明',
  `creator_id` int(11) NOT NULL COMMENT '创建人',
  `created_at` datetime(0) NOT NULL COMMENT '创建时间',
  `updated_by` int(11) NULL DEFAULT NULL COMMENT '更新人',
  `updated_at` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime(0) NULL DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 281 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '项目-资产' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_damage_scenario
-- ----------------------------
DROP TABLE IF EXISTS `project_damage_scenario`;
CREATE TABLE `project_damage_scenario`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '项目id',
  `category_dict_id` bigint(20) NOT NULL COMMENT '分类字典id 对应asset',
  `category_dict_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '分类字典名称',
  `asset_dict_id` bigint(20) NOT NULL COMMENT '资产id',
  `asset_dict_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '资产名称',
  `asset_property_id` bigint(20) NULL DEFAULT NULL COMMENT '资产配置id',
  `asset_property_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '资产配置名称',
  `damage_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '威胁场景描述',
  `creator_id` int(11) NOT NULL COMMENT '创建人',
  `created_at` datetime(0) NOT NULL COMMENT '创建时间',
  `updated_by` int(11) NULL DEFAULT NULL COMMENT '更新人',
  `updated_at` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime(0) NULL DEFAULT NULL COMMENT '删除标识',
  `impact_rating` bigint(20) NULL DEFAULT NULL COMMENT '最终评级对应字典的id',
  `asset_id` int(11) NULL DEFAULT NULL COMMENT '资产表的id',
  `impact_rating_value` decimal(10, 0) NULL DEFAULT NULL COMMENT '最终评级得分',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1482 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '项目-损害场景' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_damage_scenario_impact
-- ----------------------------
DROP TABLE IF EXISTS `project_damage_scenario_impact`;
CREATE TABLE `project_damage_scenario_impact`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_id` int(11) NULL DEFAULT NULL COMMENT '项目id',
  `damage_scenario_id` bigint(20) NULL DEFAULT NULL COMMENT '损害场景表对应记录id',
  `category_dict_id` bigint(20) NULL DEFAULT NULL COMMENT '该字段所属字典id 对应asset_property',
  `category_dict_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '该字段所属字典名称',
  `dict_id` bigint(20) NULL DEFAULT NULL COMMENT '字典id 自身数据',
  `dict_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '字典名称',
  `creator_id` int(11) NOT NULL COMMENT '创建人',
  `created_at` datetime(0) NOT NULL COMMENT '创建时间',
  `updated_by` int(11) NULL DEFAULT NULL COMMENT '更新人',
  `updated_at` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime(0) NULL DEFAULT NULL COMMENT '删除标识',
  `dict_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3402 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '项目-损害场景-影响级别' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_permission
-- ----------------------------
DROP TABLE IF EXISTS `project_permission`;
CREATE TABLE `project_permission`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_process_status
-- ----------------------------
DROP TABLE IF EXISTS `project_process_status`;
CREATE TABLE `project_process_status`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `project_id` int(11) NOT NULL COMMENT '项目',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态',
  `created_time` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `updated_time` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '发生时间',
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '消息',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '项目的报告的处理状态' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_space
-- ----------------------------
DROP TABLE IF EXISTS `project_space`;
CREATE TABLE `project_space`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enterprise` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '公司名称',
  `enterprise_short` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '公司简称',
  `platform_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '平台名称',
  `vehicle_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `target_system` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '目标系统',
  `security_task` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '安全任务',
  `project_platform` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '项目平台',
  `status` tinyint(1) UNSIGNED ZEROFILL NOT NULL COMMENT '状态',
  `creator_id` int(11) NOT NULL COMMENT '创建人',
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `updated_id` int(11) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '版本',
  `auth_group_id` int(11) NOT NULL COMMENT '所属组id',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 47 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_space_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `project_space_user_permissions`;
CREATE TABLE `project_space_user_permissions`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `space_id` int(11) NOT NULL COMMENT '项目空间id',
  `creator_id` int(11) NOT NULL COMMENT '创建人id',
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `is_super` tinyint(1) NULL DEFAULT NULL COMMENT '当前项目空间的主要管理员',
  `permission_id` int(11) NOT NULL COMMENT '权限类型id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 65 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_step
-- ----------------------------
DROP TABLE IF EXISTS `project_step`;
CREATE TABLE `project_step`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `project_information` tinyint(1) NULL DEFAULT NULL COMMENT '项目信息',
  `item_definition` tinyint(1) NULL DEFAULT NULL COMMENT '对象定义',
  `asset_identification` tinyint(1) NULL DEFAULT NULL COMMENT '资产识别',
  `damage_analysis` tinyint(1) NULL DEFAULT NULL COMMENT '危害分析',
  `threats_analysis` tinyint(1) NULL DEFAULT NULL COMMENT '威胁分析',
  `risk_assessment` tinyint(1) NULL DEFAULT NULL COMMENT '风险评估',
  `security_goal` tinyint(1) NULL DEFAULT NULL COMMENT '安全目标',
  `requirement_allocation` tinyint(1) NULL DEFAULT NULL COMMENT '网络安全需求分配',
  `concept_allocation` tinyint(1) NULL DEFAULT NULL COMMENT '网络安全概念分配',
  `risk_re_assessment` tinyint(1) NULL DEFAULT NULL COMMENT '风险重估',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `security_claim` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 53 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_system
-- ----------------------------
DROP TABLE IF EXISTS `project_system`;
CREATE TABLE `project_system`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_id` int(11) NOT NULL COMMENT '项目id',
  `overview` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '概述',
  `operational_environment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '操作环境',
  `system_information` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '系统信息',
  `network_topology` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '网络拓扑架构',
  `functions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '功能描述',
  `exisiting_security_measures` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '现有安全措施',
  `assumptions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '假设',
  `constraints` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '约束',
  `sub_systems` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '子系统',
  `components` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '组件',
  `creator_id` int(11) NOT NULL COMMENT '创建人',
  `created_at` datetime(0) NOT NULL COMMENT '创建时间',
  `updated_id` int(11) NULL DEFAULT NULL COMMENT '更新人',
  `updated_at` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime(0) NULL DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 53 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '项目-系统描述' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for project_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `project_user_permissions`;
CREATE TABLE `project_user_permissions`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `project_id` int(11) NOT NULL COMMENT '项目空间id',
  `creator_id` int(11) NOT NULL COMMENT '创建人id',
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `is_super` tinyint(1) NULL DEFAULT NULL COMMENT '当前项目空间的主要管理员',
  `permission_id` int(11) NOT NULL COMMENT '权限类型',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for projects
-- ----------------------------
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '标题',
  `desc` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '描述',
  `analysis_object` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '分析对象',
  `inputs` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '输入项',
  `creator_id` int(11) NOT NULL COMMENT '建立人用户ID（对应表auth_user）',
  `created_at` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_id` int(11) NULL DEFAULT NULL COMMENT '最后更新人id',
  `updated_at` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `activities` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '工作概述',
  `output` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '输出项',
  `space_id` int(11) NULL DEFAULT NULL COMMENT '所属项目空间id',
  `target_object` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '目标对象',
  `project_toe` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'toe',
  `document_version` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '状态',
  `authors` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reviewers` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '审核',
  `author_department` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `author_company` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `author_phone_num` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `document_class` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `document_secrecy_level` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `document_history` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '文档历史',
  `todo_list` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '待办',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `creator_id`(`creator_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 94 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '项目/工程' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for push_log
-- ----------------------------
DROP TABLE IF EXISTS `push_log`;
CREATE TABLE `push_log`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL COMMENT '项目id',
  `start_time` datetime(0) NOT NULL COMMENT '开始时间',
  `end_time` datetime(0) NULL DEFAULT NULL COMMENT '结束时间',
  `space_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '项目空间名称',
  `db_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '对应数据库',
  `table_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '对应的表名',
  `exception` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '异常',
  `push_user_id` int(11) NULL DEFAULT NULL COMMENT '推送人id',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '状态描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 236 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for risk_ratings
-- ----------------------------
DROP TABLE IF EXISTS `risk_ratings`;
CREATE TABLE `risk_ratings`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `impact_rating` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '影响等级值',
  `feasibility_rating` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '攻击可行性等级值',
  `risk_rating` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '风险等级值',
  `created_at` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '风险值\r\n依据：影响等级值、攻击可行性等级值' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for setting
-- ----------------------------
DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `value` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `created_at` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `code`(`code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统设置' ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
