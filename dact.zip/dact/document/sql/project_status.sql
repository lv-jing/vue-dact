/*
 Navicat Premium Data Transfer

 Source Server         : mysql-tara
 Source Server Type    : MySQL
 Source Server Version : 50739
 Source Host           : 192.168.203.133:3306
 Source Schema         : project_space

 Target Server Type    : MySQL
 Target Server Version : 50739
 File Encoding         : 65001

 Date: 05/12/2022 15:17:28
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for project_status
-- ----------------------------
DROP TABLE IF EXISTS `project_status`;
CREATE TABLE `project_status`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Status` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NULL,
  `Time_Stamp` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NULL,
  `Project_ID` int(11) NULL DEFAULT NULL,
  `Message` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf32 COLLATE = utf32_unicode_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
