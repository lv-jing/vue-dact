function setTime(fun){
    setInterval(function (){
        fun()
    },600000)
}
function successMesgShow(){
    $('.toast').toast('show');
    $('#msg_success').show()
}