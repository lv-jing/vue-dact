// 获取COOKIE
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
var csrftoken = getCookie("csrftoken");

function ajaxGet(url,data,callable){
    $.ajax({
        url: url,
        data: data,
        headers: {"X-CSRFToken": csrftoken},
        contentType: "application/json",
        type: "get",
        success: callable,
   });
}
// post请求
function ajaxPost(url,data,callable){
     $.ajax({
        url: url,
        data: JSON.stringify(data),
        headers: {"X-CSRFToken": csrftoken},
        contentType: "application/json",
        type: "post",
        success: callable,
    });
}

function getRouterParams(paramName){
      let href = window.location.href;
      let query = href.substring(href.indexOf('?')+1);
      let vars = query.split("&");
      obj = {}
      for (var i = 0; i < vars.length; i++) {
            let pair = vars[i].split("=");
            obj[pair[0]] = pair[1]
            if (paramName !=null && paramName == pair[0] ){
                 return obj;
            }

       }
       return obj;

}
