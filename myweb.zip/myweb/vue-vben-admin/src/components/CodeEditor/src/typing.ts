export enum MODE {
  JSON = 'application/json',
  HTML = 'htmlmixed',
  JS = 'javascript',
}
