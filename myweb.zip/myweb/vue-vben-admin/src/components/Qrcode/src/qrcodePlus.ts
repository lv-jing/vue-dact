// 参考 qr-code-with-logo 进行ts版本修改
import { toCanvas } from './toCanvas';
export * from './typing';
export { toCanvas };
