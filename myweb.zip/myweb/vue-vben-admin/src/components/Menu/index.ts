import BasicMenu from './src/BasicMenu.vue';

export { BasicMenu };
